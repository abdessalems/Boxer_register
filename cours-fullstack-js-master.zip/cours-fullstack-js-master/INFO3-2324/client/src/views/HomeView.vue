<script setup lang="ts">
import YugiohCards from '../components/YugiohCards.vue'
</script>

<template>
  <main>
    <YugiohCards />
  </main>
</template>
