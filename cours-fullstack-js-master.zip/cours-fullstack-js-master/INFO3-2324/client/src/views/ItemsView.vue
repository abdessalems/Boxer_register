<script setup lang="ts">
import ItemList from '../components/ItemList.vue'
</script>

<template>
  <main>
    <ItemList />
  </main>
</template>
