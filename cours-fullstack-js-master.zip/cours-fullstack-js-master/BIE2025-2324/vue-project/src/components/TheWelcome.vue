<script setup lang="ts"></script>

<template>Welcome to vuejs</template>
