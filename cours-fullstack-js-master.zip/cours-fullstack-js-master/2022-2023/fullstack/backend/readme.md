# explications

- Babel: traspile du JS. Permet d'écrire du JS moderne tout en supportant tous les naviateurs
- Transpiler: Passer d'un langage vers une autre langage qui a le même niveau d'abstraction
- eslint: l'outil linter pour JS et TS
  - linter: détecte les mauvaises pratiques de programmation (on appelle ça aussi du code smell)
